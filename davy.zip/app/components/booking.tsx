export default function Bookings() {

}